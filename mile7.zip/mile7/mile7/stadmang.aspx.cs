﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace mile7
{
    public partial class stadmang : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            string s = Class1.storevalue;

            Response.Write(s);
        }

        protected void stadInfo_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            string user = Class1.storevalue;

            SqlCommand check_Club = new SqlCommand("Stadium", conn);
            check_Club.CommandType = CommandType.Text;
            check_Club.CommandText = "select * FROM Stadium s inner join StadiumManger sm ON s.id=sm.stadiumid ";


            // check_Club.Parameters.AddWithValue("@ID", name);

            conn.Open();
            SqlDataReader b = check_Club.ExecuteReader(CommandBehavior.CloseConnection);
            //b.Read();
            while (b.Read())
            {
                if (b.GetString(b.GetOrdinal("username")) == user)
                {
                    int sid = b.GetInt32(b.GetOrdinal("id"));
                    String sn = b.GetString(b.GetOrdinal("name"));
                    int sc = b.GetInt32(b.GetOrdinal("capacity"));
                    String st;
                    if (b.GetBoolean(b.GetOrdinal("status")) == true)
                    {
                        st = "available";
                    }
                    else
                    {
                        st = "unavailable";
                    }
                    String sl = b.GetString(b.GetOrdinal("location"));
                    Label label1 = new Label();
                    label1.Text = "ID:" + sid + ", NAME:" + sn + ", CAPACITY:" + sc + ", LOCATION:" + sl + ", STATUS:" + st;
                    form1.Controls.Add(label1);

                }
            }
            //  conn.Close();
        }

        protected void sentReq_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            string user = Class1.storevalue;

            SqlCommand allReq = new SqlCommand("allRequests1", conn);
            allReq.CommandType = CommandType.Text;
            allReq.CommandText = "select * from allRequests1 where username=@user";

            allReq.Parameters.AddWithValue(@user, user);

            //conn.Open();
            //SqlDataReader b = allReq.ExecuteReader(CommandBehavior.CloseConnection);
            //b.Read();


            using (conn)
            {

                conn.Open();
                SqlCommand cmd = new SqlCommand("select * from allRequests1 where username=@user ", conn);
                cmd.Parameters.AddWithValue("@user", user);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    GridView4.DataSource = dr;
                    GridView4.DataBind();
                }
                conn.Close();



            }
        }

        protected void acceptReq_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            string user = Class1.storevalue;
            if (String.IsNullOrEmpty(hname.Text) || String.IsNullOrEmpty(gname.Text) || String.IsNullOrEmpty(startT.Text))
            {
                Response.Write("Host name, guest name and startTime can't be empty!");
                return;
            }
            String h = hname.Text;
            String g = gname.Text;
            String st = startT.Text;
            DateTime date1;
            bool dateCorrect = DateTime.TryParse(st, out date1);
            if (dateCorrect == false)
            {
                Response.Write("invalid type of startTime!!");
                return;
            }

            SqlCommand allReq = new SqlCommand("allRequests1", conn);
            allReq.CommandType = CommandType.Text;
            allReq.CommandText = "select * from allRequests1 ";

            conn.Open();
            SqlDataReader b = allReq.ExecuteReader(CommandBehavior.CloseConnection);
            //b.Read();
            Boolean validInputs = false;

            while (b.Read())
            {
                if (b.GetString(b.GetOrdinal("username")) == user && b.GetString(b.GetOrdinal("chname")) == h
                    && b.GetString(b.GetOrdinal("cgname")) == g && b.GetString(b.GetOrdinal("status")) == "unhandled"
                    && b.GetDateTime(b.GetOrdinal("startTime")) == date1)
                {
                    validInputs = true;
                }
            }
            if (validInputs == false)
            {
                Response.Write("There is no request with these inputs or the request is already handled.");
                return;

            }

            SqlCommand acceptProc = new SqlCommand("acceptRequest", conn);
            acceptProc.CommandType = CommandType.StoredProcedure;
            acceptProc.Parameters.Add(new SqlParameter("@s_mng", user));
            acceptProc.Parameters.Add(new SqlParameter("@h_name", h));
            acceptProc.Parameters.Add(new SqlParameter("@g_name", g));
            acceptProc.Parameters.Add(new SqlParameter("@startTime", date1));

            conn.Open();
            acceptProc.ExecuteNonQuery();
            conn.Close();
        }

        protected void rejectReq_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            string user = Class1.storevalue;
            if (String.IsNullOrEmpty(hname.Text) || String.IsNullOrEmpty(gname.Text) || String.IsNullOrEmpty(startT.Text))
            {
                Response.Write("Host name, guest name and start time can't be empty!");
                return;
            }
            String h = hname.Text;
            String g = gname.Text;
            String st = startT.Text;
            DateTime date1;
            bool dateCorrect = DateTime.TryParse(st, out date1);
            if (dateCorrect == false)
            {
                Response.Write("invalid type of startTime!!");
                return;
            }

            Boolean validInputs = false;
            SqlCommand allReq = new SqlCommand("allRequests1", conn);
            allReq.CommandType = CommandType.Text;
            allReq.CommandText = "select * from allRequests1 ";

            conn.Open();
            SqlDataReader b = allReq.ExecuteReader(CommandBehavior.CloseConnection);
            //b.Read();
            while (b.Read())
            {
                if (b.GetString(b.GetOrdinal("username")) == user && b.GetString(b.GetOrdinal("chname")) == h
                    && b.GetString(b.GetOrdinal("cgname")) == g && b.GetString(b.GetOrdinal("status")) == "unhandled"
                   && b.GetDateTime(b.GetOrdinal("startTime")) == date1)
                {
                    validInputs = true;
                }
            }
            if (validInputs == false)
            {
                Response.Write("There is no request with these inputs or the request is already handled.");
                return;

            }

            SqlCommand rejectProc = new SqlCommand("rejectRequest", conn);
            rejectProc.CommandType = CommandType.StoredProcedure;
            rejectProc.Parameters.Add(new SqlParameter("@s_mng", user));
            rejectProc.Parameters.Add(new SqlParameter("@h_name", h));
            rejectProc.Parameters.Add(new SqlParameter("@g_name", g));
            rejectProc.Parameters.Add(new SqlParameter("@startTime", date1));

            conn.Open();
            rejectProc.ExecuteNonQuery();
            conn.Close();
        }
    }
}