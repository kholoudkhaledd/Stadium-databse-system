﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace mile7
{
    public class Class1
    {
        public static string storevalue;
        public static string storevaluenewuser;
        public static string storevaluenewname;
        public static string nationalidofclass1;


    }
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void sam_Click(object sender, EventArgs e)
        {

            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            String user = username.Text;
            String pass = password.Text;
            Class1.storevalue = user;

            SqlCommand check_CR = new SqlCommand("SELECT COUNT(*) FROM [sam] WHERE ([username]=@user)", conn);
            SqlCommand check_User = new SqlCommand("SELECT COUNT(*) FROM [systemUser] WHERE ([username]=@user AND [pass]=@pass)", conn);

            check_CR.Parameters.AddWithValue("@user", user);
            check_User.Parameters.AddWithValue("@user", user);
            check_User.Parameters.AddWithValue("@pass", pass);
            conn.Open();
            int CRExist = (int)check_CR.ExecuteScalar();
            int UserExist = (int)check_User.ExecuteScalar();
            conn.Close();



            if (UserExist > 0 && CRExist > 0)
            {
                //Username exist
                Class1.storevalue = user;
                Response.Redirect("SAM.aspx");

            }
            else
            {
                //Username doesn't exist
                Response.Write("Invalid username or password in Club assiociative manager!!!!");
            }
        }

        protected void clubRep_Click(object sender, EventArgs e)
        {

            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            String user = username.Text;
            String pass = password.Text;
            Class1.storevalue = user;

            SqlCommand check_CR = new SqlCommand("SELECT COUNT(*) FROM [ClubRepresentative] WHERE ([username]=@user)", conn);
            SqlCommand check_User = new SqlCommand("SELECT COUNT(*) FROM [systemUser] WHERE ([username]=@user AND [pass]=@pass)", conn);

            check_CR.Parameters.AddWithValue("@user", user);
            check_User.Parameters.AddWithValue("@user", user);
            check_User.Parameters.AddWithValue("@pass", pass);
            conn.Open();
            int CRExist = (int)check_CR.ExecuteScalar();
            int UserExist = (int)check_User.ExecuteScalar();
            conn.Close();

            

            if (UserExist > 0 && CRExist > 0)
            {
                //Username exist
                Class1.storevalue = user;
                Response.Redirect("ClubRep.aspx");

            }
            else
            {
                //Username doesn't exist
                Response.Write("Invalid username or password in Club Representative!!!!");
            }
        }

        protected void stadiumManag_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            if (String.IsNullOrEmpty(username.Text) || String.IsNullOrEmpty(password.Text))
            {
                Response.Write("Username and password can't be empty!");
                return;
            }
            String user = username.Text;
            String pass = password.Text;
            Class1.storevalue = user;

            SqlCommand check_SM = new SqlCommand("SELECT COUNT(*) FROM [stadiumManger] WHERE ([username]=@user)", conn);
            SqlCommand check_User = new SqlCommand("SELECT COUNT(*) FROM [systemUser] WHERE ([username]=@user AND [pass]=@pass)", conn);

            check_SM.Parameters.AddWithValue("@user", user);
            check_User.Parameters.AddWithValue("@user", user);
            check_User.Parameters.AddWithValue("@pass", pass);
            conn.Open();
            int SMExist = (int)check_SM.ExecuteScalar();
            int UserExist = (int)check_User.ExecuteScalar();
            conn.Close();



            if (UserExist > 0 && SMExist > 0)
            {
                //Username exist
                Class1.storevalue = user;
                Response.Redirect("stadmang.aspx");

            }
            else
            {
                //Username doesn't exist
                Response.Write("Invalid username or password in Stadium Manager!!!!");
            }
        }

        protected void fan_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            if (String.IsNullOrEmpty(username.Text) || String.IsNullOrEmpty(password.Text))
            {
                Response.Write("Username and password can't be empty!");
                return;
            }
            String user = username.Text;
            String pass = password.Text;
            Class1.storevalue = user;

            SqlCommand check_SM = new SqlCommand("SELECT COUNT(*) FROM [fan] WHERE ([username]=@user)", conn);
            SqlCommand check_User = new SqlCommand("SELECT COUNT(*) FROM [systemUser] WHERE ([username]=@user AND [pass]=@pass)", conn);

            check_SM.Parameters.AddWithValue("@user", user);
            check_User.Parameters.AddWithValue("@user", user);
            check_User.Parameters.AddWithValue("@pass", pass);
            conn.Open();
            int SMExist = (int)check_SM.ExecuteScalar();
            int UserExist = (int)check_User.ExecuteScalar();
            conn.Close();



            if (UserExist > 0 && SMExist > 0)
            {
                //Username exist
                Class1.storevalue = user;
                Response.Redirect("fan.aspx");

            }
            else
            {
                //Username doesn't exist
                Response.Write("Invalid username or password in Fan!!!!");
            }
        }

        protected void login1_Click(object sender, EventArgs e)
        {
            Response.Redirect("newuserpage.aspx");
        }

        protected void systemAdmin_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            String user = username.Text;
            String pass = password.Text;

            SqlCommand check_SA = new SqlCommand("SELECT COUNT(*) FROM [systemAdmin] WHERE ([username] = @user)", conn);
            SqlCommand check_User = new SqlCommand("SELECT COUNT(*) FROM [systemUser] WHERE ([username] = @user AND [pass]=@pass)", conn);

            check_SA.Parameters.AddWithValue("@user", user);
            check_User.Parameters.AddWithValue("@user", user);
            check_User.Parameters.AddWithValue("@pass", pass);
            conn.Open();
            int SAExist = (int)check_SA.ExecuteScalar();
            int UserExist = (int)check_User.ExecuteScalar();
            conn.Close();

            


            if (UserExist  > 0 && SAExist>0)
            {
                //Username exist
                Response.Redirect("SystemAdminAccess.aspx");

            }
            else
            {
                //Username doesn't exist
                Response.Write("Invalid username or password in system admin!!!!");
            }

           

        }
    }
}