﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Drawing;

namespace mile7
{
    public partial class SAM : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            usersam.Text = Class1.storevaluenewuser;
            samname.Text = Class1.storevaluenewname;

        }

        protected void addmatchsam_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            string hc = hostname.Text;
            string gc = guestname.Text;
            string st = starttimeofsame.Text;
            string et = endtimesam.Text;
            DateTime date1;
            bool dateCorrect = DateTime.TryParse(st, out date1);
            DateTime date2;
            bool dateCorrect1 = DateTime.TryParse(et, out date2);
            if (!dateCorrect || String.IsNullOrEmpty(hc) || String.IsNullOrEmpty(gc) || String.IsNullOrEmpty(st) ||
              String.IsNullOrEmpty(et) || date2 <= date1)
            {
                Response.Write(" Invalid input ");
                return;
            }
            SqlCommand matchproc = new SqlCommand("addNewMatch", conn);
            matchproc.CommandType = CommandType.StoredProcedure;
            matchproc.Parameters.Add(new SqlParameter("@h_name", hc));
            matchproc.Parameters.Add(new SqlParameter("@g_name", gc));
            matchproc.Parameters.Add(new SqlParameter("@startTime", date1));
            matchproc.Parameters.Add(new SqlParameter("@endTime", date2));
            SqlCommand check_club = new SqlCommand("select count (*) from club where name= @hc or name= @gc",conn);
            check_club.Parameters.AddWithValue("@hc", hc);
            check_club.Parameters.AddWithValue("@gc", gc);
 SqlCommand check_match = new SqlCommand("SELECT COUNT(*) FROM allMatches WHERE [Host Club]= @hc and  [Guest Club] = @gc and [startTime]= @date1 and [endTime]= @date2 ", conn);
            check_match.Parameters.AddWithValue("@hc", hc);
            check_match.Parameters.AddWithValue("@gc", gc);
            check_match.Parameters.AddWithValue("@date1", date1);
            check_match.Parameters.AddWithValue("@date2", date2);
            int matchexist = (int)check_match.ExecuteScalar();
        
            int clubsexist = (int)check_club.ExecuteScalar();
         
     
            if (clubsexist == 2 && matchexist==0)
            {
                matchproc.ExecuteNonQuery();
                Response.Write(" match is added succesfully  ");
            }
            else
            {
                Response.Write(" no club with such name  or match alraedy exist  ");
                return;
            }
            conn.Close();
        }

        protected void deletematchsam_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            string hc = hostname.Text;
            string gc = guestname.Text;
            string st = starttimeofsame.Text;
            string et = endtimesam.Text;
            DateTime date1;
            bool dateCorrect = DateTime.TryParse(st, out date1);
            DateTime date2;
            bool dateCorrect1 = DateTime.TryParse(et, out date2);
            if (!dateCorrect || date2 <= date1 || String.IsNullOrEmpty(hc) || String.IsNullOrEmpty(gc) || String.IsNullOrEmpty(st) ||
                String.IsNullOrEmpty(et) || !dateCorrect)
            {
                Response.Write(" Invalid input ");
                return;
            }

            SqlCommand matchproc2 = new SqlCommand("deleteMatch", conn);
            matchproc2.CommandType = CommandType.StoredProcedure;
            matchproc2.Parameters.Add(new SqlParameter("@namehclub ", hc));
            matchproc2.Parameters.Add(new SqlParameter("@namegclub", gc));
            matchproc2.Parameters.Add(new SqlParameter("@startTime", date1));
            matchproc2.Parameters.Add(new SqlParameter("@endTime", date2));

            SqlCommand check_match = new SqlCommand("SELECT COUNT(*) FROM allMatches WHERE [Host Club]= @hc and  [Guest Club] = @gc and [startTime]= @date1 and [endTime]= @date2 ", conn);
            check_match.Parameters.AddWithValue("@hc", hc);
            check_match.Parameters.AddWithValue("@gc", gc);
            check_match.Parameters.AddWithValue("@date1", date1);
            check_match.Parameters.AddWithValue("@date2", date2);


            int matchexist = (int)check_match.ExecuteScalar();

            if (matchexist > 0)
            {
             
                matchproc2.ExecuteNonQuery();
                Response.Write("match is deleted succesfully");
            }
            else
            {
                Response.Write("Sorry but match doesn't even exist ");
            }

            conn.Close();
        }

        protected void viewupmatches_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            using (conn)
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("select * from allMatches as a where a.startTime>=CURRENT_TIMESTAMP ", conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    GridView3.DataSource = dr;
                    GridView3.DataBind();
                }

            }
        }

        protected void playedmatches_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            using (conn)
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("select * from allMatches as a where a.startTime<CURRENT_TIMESTAMP ", conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    GridView2.DataSource = dr;
                    GridView2.DataBind();
                }

            }
        }
        protected void neverb_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            using (conn)
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select * from ClubsNeverMatched ", conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    GridView1.DataSource = dr;
                    GridView1.DataBind();
                }

            }

        }
        protected void GVBIND()
        {

        }
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}