﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using System.Web.Configuration;
using System.Runtime.Remoting.Metadata.W3cXsd2001;

namespace mile7
{
    public partial class ClubRep : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void addHR_Click(object sender, EventArgs e)
        {

            if (String.IsNullOrEmpty(club.Text) || String.IsNullOrEmpty(stad.Text) || String.IsNullOrEmpty(startingTime.Text))
            {
                Response.Write("Club Name, Stadium Name, and Starting Time can't be empty!");
                return;
            }
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);


            string cn = club.Text;
            string sn = stad.Text;
            string st = startingTime.Text;

            DateTime date1;
            bool dateCorrect = DateTime.TryParse(st, out date1);
            if (dateCorrect == false)
            {
                Response.Write("Please write a valid DateTime");
            }

            Boolean validInputs = false;
            SqlCommand check_Club = new SqlCommand("SELECT COUNT(*) FROM [Club] WHERE ([name] = @name )", conn);
            check_Club.Parameters.AddWithValue("@name", cn);
            conn.Open();
            int ClubExist = (int)check_Club.ExecuteScalar();
            conn.Close();

            SqlCommand check_Stad = new SqlCommand("SELECT COUNT(*) FROM [Stadium] WHERE ([name] = @name )", conn);
            check_Stad.Parameters.AddWithValue("@name", sn);
            conn.Open();
            int stadExist = (int)check_Stad.ExecuteScalar();
            conn.Close();



            if (ClubExist > 0 && stadExist > 0)
            {
                //Club exist
                validInputs = true;
            }
            if (validInputs == true)
            {
                SqlCommand addHostProc = new SqlCommand("addHostRequest", conn);
                addHostProc.CommandType = CommandType.StoredProcedure;
                addHostProc.Parameters.Add(new SqlParameter("@clubName", cn));
                addHostProc.Parameters.Add(new SqlParameter("@StadiumName", sn));
                addHostProc.Parameters.Add(new SqlParameter("@startingTime", date1));

                conn.Open();
                addHostProc.ExecuteNonQuery();
                conn.Close();
                Response.Write("Host Request has been successfully sent!");
            }
            else
            {
                Response.Write("club/stadium name is INVALID");
            }

        }

        protected void availableStads_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(time.Text))
            {
                Response.Write("Time can't be empty!");
                return;
            }
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            string user = Class1.storevalue;
            string st = time.Text;

            DateTime date1; //= DateTime.Parse( time.Text);
            bool dateCorrect = DateTime.TryParse(st, out date1);
            if (dateCorrect == false)
            {
                Response.Write("put a valid dateTime!!");
                return;
            }

            SqlCommand availableStadFnc = new SqlCommand("SELECT * FROM dbo.viewAvailableStadiumsOn(@timeAndDate)", conn);

            availableStadFnc.Parameters.AddWithValue("@timeAndDate", date1);


            //b.Read();
            using (conn)
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.viewAvailableStadiumsOn(@timeAndDate)  ", conn);
                cmd.Parameters.AddWithValue("@timeAndDate", date1);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows == true)
                {
                    GridView4.DataSource = dr;
                    GridView4.DataBind();
                }
                conn.Close();
            }
        }
        protected void upcomingMatches_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(repClub.Text))
            {
                Response.Write("Club Name can't be empty!");
                return;
            }
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            string user = Class1.storevalue;
            string cn = repClub.Text;

            Boolean validInputs = false;
            SqlCommand check_Club = new SqlCommand("SELECT COUNT(*) FROM ClubRepresentative cr inner join Club c On c.id=cr.club_ID WHERE (cr.username=@name AND c.name=@club )", conn);
            check_Club.Parameters.AddWithValue("@name", user);
            check_Club.Parameters.AddWithValue("@club", cn);
            conn.Open();
            int ClubExist = (int)check_Club.ExecuteScalar();
            conn.Close();

            if (ClubExist > 0)
            {
                validInputs = true;
            }
            if (validInputs == true)
            {
              


                //SqlDataReader b = upcomingFnc.ExecuteReader(CommandBehavior.CloseConnection);
                //b.Read();
                using (conn)
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.upcomingMatchesOfClub(@x)  ", conn);
                    cmd.Parameters.AddWithValue("@x", cn);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.HasRows == true)
                    {
                        GridView4.DataSource = dr;
                        GridView4.DataBind();
                    }
                    conn.Close();


                }
            }
            else
            {
                Response.Write("Please enter the club name you represent");
            }



        }

        protected void clubInfo_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            string user = Class1.storevalue;

            SqlCommand check_Club = new SqlCommand("Club", conn);
            check_Club.CommandType = CommandType.Text;
            check_Club.CommandText = "select * FROM club c inner join ClubRepresentative cr ON c.id=cr.club_ID ";

            conn.Open();
            SqlDataReader b = check_Club.ExecuteReader(CommandBehavior.CloseConnection);
            //b.Read();
            while (b.Read())
            {
                if (b.GetString(b.GetOrdinal("username")) == user)
                {
                    int cid = b.GetInt32(b.GetOrdinal("id"));
                    String cn = b.GetString(b.GetOrdinal("name"));
                    String sl = b.GetString(b.GetOrdinal("location"));
                    Label label1 = new Label();
                    label1.Text = cid + " " + cn + " " + sl;
                    form1.Controls.Add(label1);

                }
            }

        }
    }
}