﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace mile7
{

    public partial class newuserpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void bsam_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            if (String.IsNullOrEmpty(newname.Text) || String.IsNullOrEmpty(newusername.Text) || String.IsNullOrEmpty(newpassword.Text))
            {
                Response.Write("Name,username,and password can't be empty!");
                return;
            }

            String n = newname.Text;
            String user = newusername.Text;
            String pass = newpassword.Text;

            SqlCommand check_User = new SqlCommand("SELECT COUNT(*) FROM [systemUser] WHERE ([username] = @user)", conn);

            check_User.Parameters.AddWithValue("@user", user);
            conn.Open();
            int UserExist = (int)check_User.ExecuteScalar();
            conn.Close();

            if (UserExist > 0)
            {
                //Username exist
                Response.Write("username already exists please change it!");
                return;
            }

            SqlCommand loginProc = new SqlCommand("addAssociationManager", conn);
            loginProc.CommandType = CommandType.StoredProcedure;
            loginProc.Parameters.Add(new SqlParameter("@name",n));
            loginProc.Parameters.Add(new SqlParameter("@username", user));
            loginProc.Parameters.Add(new SqlParameter("@password", pass));

            conn.Open();
            loginProc.ExecuteNonQuery();
            conn.Close();

            Response.Redirect("SAM.aspx");
        }

        protected void bfan_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            if (String.IsNullOrEmpty(newname.Text) || String.IsNullOrEmpty(newusername.Text) || String.IsNullOrEmpty(newpassword.Text) || 
                String.IsNullOrEmpty(nationalid.Text)|| String.IsNullOrEmpty(birthdate.Text)|| String.IsNullOrEmpty(phonenumber.Text)
                || String.IsNullOrEmpty(address.Text))
            {
                Response.Write("Name,username,nationalid, address,phonenumber or password can't be empty!");
                return;
            }
            String n = newname.Text;
            String user = newusername.Text;
            String pass = newpassword.Text;
            string natid = nationalid.Text;
            string birth = birthdate.Text;
            string addre = address.Text;
            string phone = phonenumber.Text;
            Class1.nationalidofclass1 = nationalid.Text;
            DateTime birthdate1;
            bool dateCorrect = DateTime.TryParse(birth, out birthdate1);
            SqlCommand newfan = new SqlCommand("addFan", conn);
            newfan.CommandType = CommandType.StoredProcedure;
            newfan.Parameters.Add(new SqlParameter("@name", n));
            newfan.Parameters.Add(new SqlParameter("@username", user));
            newfan.Parameters.Add(new SqlParameter("@password", pass));
            newfan.Parameters.Add(new SqlParameter("@nationaID", natid));
            newfan.Parameters.Add(new SqlParameter("@bithdate", birthdate1));
            newfan.Parameters.Add(new SqlParameter("@address ", addre));
            newfan.Parameters.Add(new SqlParameter("@phone", natid));

            SqlCommand check_User = new SqlCommand("SELECT COUNT(*) FROM [systemUser] WHERE ([username] = @user)", conn);

            check_User.Parameters.AddWithValue("@user", user);
         
            int UserExist = (int)check_User.ExecuteScalar();
        

            if (UserExist > 0)
            {
                //Username exist
                Response.Write("username already exists please change it!");
                return;
            }
            else
            {
                newfan.ExecuteNonQuery();
                Response.Redirect("Fan.aspx");
            }
            conn.Close();
        }

        protected void bStadManag_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            if (String.IsNullOrEmpty(newname.Text) || String.IsNullOrEmpty(newusername.Text) || String.IsNullOrEmpty(newpassword.Text) || String.IsNullOrEmpty(stadName.Text))
            {
                Response.Write("Name,username,Stadium name, and password can't be empty!");
                return;
            }

            String n = newname.Text;
            String user = newusername.Text;
            String pass = newpassword.Text;
            String stad = stadName.Text;
            Class1.storevalue = user;

            SqlCommand check_User = new SqlCommand("SELECT COUNT(*) FROM [systemUser] WHERE ([username] = @user)", conn);
            SqlCommand check_Stad = new SqlCommand("SELECT COUNT(*) FROM [Stadium] WHERE ([name] = @stad)", conn);

            check_User.Parameters.AddWithValue("@user", user);
            conn.Open();
            int UserExist = (int)check_User.ExecuteScalar();
            conn.Close();

            check_Stad.Parameters.AddWithValue("@stad", stad);
            conn.Open();
            int stadExist = (int)check_Stad.ExecuteScalar();
            conn.Close();

            if (UserExist > 0)
            {
                //Username exist
                Response.Write("username already exists please change it!");
                return;
            }
            else
            {
                if(stadExist == 0)
                {
                    Response.Write("There is no existance of stadium with this name!");
                    return;
                }
                SqlCommand newSMProc = new SqlCommand("addStadiumManager", conn);
                newSMProc.CommandType = CommandType.StoredProcedure;
                newSMProc.Parameters.Add(new SqlParameter("@name", n));
                newSMProc.Parameters.Add(new SqlParameter("@username", user));
                newSMProc.Parameters.Add(new SqlParameter("@password", pass));
                newSMProc.Parameters.Add(new SqlParameter("@stadName", stad));

                conn.Open();
                newSMProc.ExecuteNonQuery();
                conn.Close();

                Response.Redirect("stadmang.aspx");
            }
            
        }

        protected void bRep_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            if (String.IsNullOrEmpty(newname.Text) || String.IsNullOrEmpty(newusername.Text) || String.IsNullOrEmpty(newpassword.Text) || String.IsNullOrEmpty(clubName.Text))
            {
                Response.Write("Name,username,club name, and password can't be empty!");
                return;
            }

            String n = newname.Text;
            String user = newusername.Text;
            String pass = newpassword.Text;
            String club = clubName.Text;

            Class1.storevalue = user;
            SqlCommand check_User = new SqlCommand("SELECT COUNT(*) FROM [systemUser] WHERE ([username] = @user)", conn);

            check_User.Parameters.AddWithValue("@user", user);
            conn.Open();
            int UserExist = (int)check_User.ExecuteScalar();
            conn.Close();

            if (UserExist > 0)
            {
                //Username exist
                Response.Write("username already exists please change it!");
                return;
            }

            SqlCommand newCRProc = new SqlCommand("addRepresentative", conn);
            newCRProc.CommandType = CommandType.StoredProcedure;
            newCRProc.Parameters.Add(new SqlParameter("@repname", n));
            newCRProc.Parameters.Add(new SqlParameter("@username", user));
            newCRProc.Parameters.Add(new SqlParameter("@password", pass));
            newCRProc.Parameters.Add(new SqlParameter("@nameofclub", club));

            conn.Open();
            newCRProc.ExecuteNonQuery();
            conn.Close();

            Response.Redirect("ClubRep.aspx");
        }
    }
}