﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace mile7
{
    public partial class SystemAdminAccess : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void addClub_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            if (String.IsNullOrEmpty(clubName.Text) || String.IsNullOrEmpty(clubLoc.Text))
            {
                Response.Write("Name and location can't be empty!");
                return;
            }
            String name = clubName.Text;
            String loc = clubLoc.Text;

            SqlCommand check_Club = new SqlCommand("SELECT COUNT(*) FROM [club] WHERE ([name] = @name AND [location]=@loc)", conn);

            check_Club.Parameters.AddWithValue("@name", name);
            check_Club.Parameters.AddWithValue("@loc", loc);
            conn.Open();
            int ClubExist = (int)check_Club.ExecuteScalar();
            conn.Close();

            if (ClubExist > 0)
            {
                //Club exist
                Response.Write("This Club already Exists!");
            }
            else
            {
                //Club doesn't exist
                SqlCommand addClubProc = new SqlCommand("addClub", conn);
                addClubProc.CommandType = CommandType.StoredProcedure;
                addClubProc.Parameters.Add(new SqlParameter("@names", name));
                addClubProc.Parameters.Add(new SqlParameter("@locations", loc));

                conn.Open();
                addClubProc.ExecuteNonQuery();
                conn.Close();
                Response.Write("Club successfuly added!");
            }

        }

        protected void deleteClub_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            if (String.IsNullOrEmpty(clubName.Text))
            {
                Response.Write("Name can't be empty!");
                return;
            }

            String name = clubName.Text;

            SqlCommand check_Club = new SqlCommand("SELECT COUNT(*) FROM [club] WHERE ([name] = @name)", conn);
            SqlCommand check_ClubRep = new SqlCommand("SELECT COUNT(*) FROM club c inner join ClubRepresentative cr on c.id=cr.club_ID WHERE (c.name = @name)", conn);
            check_ClubRep.Parameters.AddWithValue("@name", name);
            conn.Open();
            int ClubRepExist = (int)check_ClubRep.ExecuteScalar();
            conn.Close();

            check_Club.Parameters.AddWithValue("@name", name);
            conn.Open();
            int ClubExist = (int)check_Club.ExecuteScalar();
            conn.Close();
            if (ClubRepExist > 0)
            {
                Response.Write("Club can't be deleted because there is a representative for it on the system!");
                return;
            }

            if (ClubExist > 0)
            {
                //Club exist
                SqlCommand deleteClubProc = new SqlCommand("deleteClub", conn);
                deleteClubProc.CommandType = CommandType.StoredProcedure;
                deleteClubProc.Parameters.Add(new SqlParameter("@clubName", name));

                conn.Open();
                deleteClubProc.ExecuteNonQuery();
                conn.Close();
                Response.Write("Club successfuly deleted!");
            }
            else
            {
                //Club doesn't exist

                Response.Write("No Club Exists with this name!");
            }
        }

        protected void AddStad_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);

            if (String.IsNullOrEmpty(StadName.Text) || String.IsNullOrEmpty(StadLoc.Text) || String.IsNullOrEmpty(StadCap.Text))
            {
                Response.Write("Name,location,and capacity can't be empty!");
                return;
            }
            int parsedValue;
            if (!int.TryParse(StadCap.Text, out parsedValue))
            {
                Response.Write("Only numbers are allowed in capacity field!");
                return;
            }

            String name = StadName.Text;
            String loc = StadLoc.Text;
            int cap = Int16.Parse(StadCap.Text);

            SqlCommand check_Club = new SqlCommand("SELECT COUNT(*) FROM [Stadium] WHERE ([name] = @name AND [capacity]=@cap AND [location]=@loc )", conn);

            check_Club.Parameters.AddWithValue("@name", name);
            check_Club.Parameters.AddWithValue("@loc", loc);
            check_Club.Parameters.AddWithValue("@cap", cap);
            conn.Open();
            int StadExist = (int)check_Club.ExecuteScalar();
            conn.Close();

            if (StadExist > 0)
            {
                //Club exist
                Response.Write("This Stadium already Exists!");
            }
            else
            {
                //Club doesn't exist
                SqlCommand addStadiumProc = new SqlCommand("addStadium", conn);
                addStadiumProc.CommandType = CommandType.StoredProcedure;
                addStadiumProc.Parameters.Add(new SqlParameter("@StadName", name));
                addStadiumProc.Parameters.Add(new SqlParameter("@stadLocation", loc));
                addStadiumProc.Parameters.Add(new SqlParameter("@capacity", cap));

                conn.Open();
                addStadiumProc.ExecuteNonQuery();
                conn.Close();
                Response.Write("Stadium successfuly added!");
            }
        }

        protected void DeleteStad_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            if (String.IsNullOrEmpty(StadName.Text))
            {
                Response.Write("Name can't be empty!");
                return;
            }

            String name = StadName.Text;

            SqlCommand check_Stad = new SqlCommand("SELECT COUNT(*) FROM [Stadium] WHERE ([name] = @name)", conn);
            SqlCommand check_SM = new SqlCommand("SELECT COUNT(*) FROM stadium s inner join stadiumManger sm on s.id=sm.stadiumid WHERE (s.name = @name)", conn);
            check_SM.Parameters.AddWithValue("@name", name);
            conn.Open();
            int SMExist = (int)check_SM.ExecuteScalar();
            conn.Close();
            check_Stad.Parameters.AddWithValue("@name", name);
            conn.Open();
            int StadbExist = (int)check_Stad.ExecuteScalar();
            conn.Close();
            if (SMExist > 0)
            {
                Response.Write("Can't delete this stadium because there is manager for it on the system!");
                return;
            }
            if (StadbExist > 0)
            {
                //Stad exist
                SqlCommand deleteStadProc = new SqlCommand("deleteStadium", conn);
                deleteStadProc.CommandType = CommandType.StoredProcedure;
                deleteStadProc.Parameters.Add(new SqlParameter("@stadiumname", name));

                conn.Open();
                deleteStadProc.ExecuteNonQuery();
                conn.Close();
                Response.Write("Stadium successfuly deleted!");
            }
            else
            {
                //Stad doesn't exist

                Response.Write("No Stadium Exists with this name!");
            }
        }

        protected void BlockFan_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            if (String.IsNullOrEmpty(fanID.Text))
            {
                Response.Write("Natinal ID can't be empty!");
                return;
            }

            String nID = fanID.Text;

            SqlCommand check_Stad = new SqlCommand("SELECT COUNT(*) FROM [Fan] WHERE ([nationalid] = @nID)", conn);

            check_Stad.Parameters.AddWithValue("@nID", nID);
            conn.Open();
            int StadbExist = (int)check_Stad.ExecuteScalar();
            conn.Close();

            if (StadbExist > 0)
            {
                //Stad exist
                SqlCommand blockFanProc = new SqlCommand("blockFan", conn);
                blockFanProc.CommandType = CommandType.StoredProcedure;
                blockFanProc.Parameters.Add(new SqlParameter("@nationalidfan", nID));

                conn.Open();
                blockFanProc.ExecuteNonQuery();
                conn.Close();
                Response.Write("Fan successfuly blocked!");
            }
            else
            {
                //Stad doesn't exist

                Response.Write("No Fan exists with this national ID!");
            }

        }
    }
}