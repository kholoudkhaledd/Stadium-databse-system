﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace mile7
{
    public partial class Fan : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void matchesforfan_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(tmatch.Text))
            {
                Response.Write("Starting Time can't be empty!");
                return;
            }
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            string st = tmatch.Text;

            DateTime date1;
            bool dateCorrect = DateTime.TryParse(st, out date1);
            SqlCommand forfan = new SqlCommand("select * from dbo.availableMatchesToAttend(@timeofmatch)", conn);
            forfan.Parameters.Add(new SqlParameter("@startTime", date1));

            if (!dateCorrect)
            {
                Response.Write("incorrect format of date");
            }
            else
            {
                Boolean validInputs = false;
                SqlCommand check_Match = new SqlCommand("SELECT COUNT(*) FROM [Matches] WHERE ([startTime]=@start )", conn);
                check_Match.Parameters.AddWithValue("@start", st);
                conn.Open();
                int ClubExist = (int)check_Match.ExecuteScalar();
                conn.Close();
                if (ClubExist > 0)
                {
                    validInputs = true;
                }
                if (validInputs)
                {
                    forfan.Parameters.AddWithValue("@timeofmatch", st);


                    //SqlDataReader b = forfan.ExecuteReader(CommandBehavior.CloseConnection);
                    //b.Read();
                    using (conn)
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.availableMatchesToAttend(@timeofmatch)  ", conn);
                        cmd.Parameters.AddWithValue("@timeofmatch", st);
                        SqlDataReader dr = cmd.ExecuteReader();
                        if (dr.HasRows == true)
                        {
                            GridView5.DataSource = dr;
                            GridView5.DataBind();
                        }
                        conn.Close();


                    }
                }
                else
                {
                    Response.Write("There are no matches on that date :(");
                }

            }
        }
        protected void purchase_Click(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["mile7"].ToString();
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            string fannid = pnid.Text;
            string hc = phost.Text;
            string gc = pgclub.Text;
            string pst = pstarttime.Text;
            string username = Class1.storevaluenewuser;
            string userlog = Class1.storevalue;

            DateTime date1;
            bool dateCorrect = DateTime.TryParse(pst, out date1);

            SqlCommand check_Club = new SqlCommand("Fan", conn);
            check_Club.CommandType = CommandType.Text;
            check_Club.CommandText = "select * FROM Fan WHERE nationalid=@nid ";
            check_Club.Parameters.AddWithValue("@nid", fannid);

            SqlDataReader b = check_Club.ExecuteReader(CommandBehavior.CloseConnection);
            //b.Read();
            while (b.Read())
            {
                if (b.GetBoolean(b.GetOrdinal("fanstatus")) == false)
                {
                    Response.Write("sorry you are blocked ");
                    return;
                }
            }
            if (!dateCorrect || String.IsNullOrEmpty(pnid.Text)
               || String.IsNullOrEmpty(phost.Text) || String.IsNullOrEmpty(pgclub.Text)
               || String.IsNullOrEmpty(pstarttime.Text) )
            {
                Response.Write("Invalid input");
                return;
            }
  SqlCommand check_CR = new SqlCommand("select count (*) from availableMatchesToAttend(@date1)  where hostclub= @hc and guestclub= @gc ", conn);
            check_CR.Parameters.AddWithValue("@date1", date1);
            check_CR.Parameters.AddWithValue("@hc", hc);
            check_CR.Parameters.AddWithValue("@gc", gc);
            int matchexist = (int)check_CR.ExecuteScalar();
            conn.Close();
            if (matchexist==0)
            {
                Response.Write(" match is not avliable to attend ");
               
            }
           
            else
            {
                SqlCommand purschaseticket = new SqlCommand("exec purchaseTicket @nationalid , @hclub, @gclub , @starttime", conn);
                purschaseticket.Parameters.AddWithValue("@nationalid", fannid);
                purschaseticket.Parameters.AddWithValue("@hclub", hc);
                purschaseticket.Parameters.AddWithValue("@gclub", gc);
                purschaseticket.Parameters.AddWithValue("@starttime", pst);
                conn.Open();
                purschaseticket.ExecuteNonQuery();

                Response.Write("ticket purchased succefully ");
                conn.Close();



            }
          

        }
        
    }
}